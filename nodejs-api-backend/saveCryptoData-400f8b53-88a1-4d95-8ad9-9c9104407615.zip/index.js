var AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-southeast-2' });
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'ap-southeast-2' }),
    TABLE_NAME = process.env.TABLE_NAME;


exports.handler = (event, context, callback) => {
    const randomString = '8rt0a8';

    let body ;
     console.log("event.body " + JSON.stringify(event));
    if (event !== null && event !== undefined) {
        console.log("event.body1 " + event);
       body = event;
    }
     var results = [];
    
    if(body){
       
        const sampleObject = body;
        if (sampleObject) {
            sampleObject.forEach(element => {
                var coinObect = {
                    date: covertDate(element.date),
                    //date : element.date,
                    currency: element.currency,
                    profit: 0.0,
                    buyValue: element.quotes[0].price,
                    sellValue: 0.0,
                    buyTime: convertTime24to12(element.quotes[0].time.slice(0, 2) + ":" + element.quotes[0].time.slice(2)),
                    sellTime: ''
                };
                var i;
                for (i = 1; i < element.quotes.length; i++) {
                    if (coinObect.buyValue < element.quotes[i].price && (element.quotes[i].price - coinObect.buyValue) > coinObect.profit) {
                        coinObect.profit = (element.quotes[i].price - coinObect.buyValue).toFixed(2);
                        coinObect.sellValue = element.quotes[i].price;
                        coinObect.sellTime = convertTime24to12(element.quotes[i].time.slice(0, 2) + ":" + element.quotes[i].time.slice(2));
                    }
                }
                results.push(coinObect);
            });
        }
    }
    const dbParams = {
        TableName: TABLE_NAME,
        Item: {
            "InputId": randomString,
            "CryptoData": body ? body : 'Hello'
        }
    }
    var dbPromise = docClient.put(dbParams).promise();
    
    Promise.all([dbPromise]).then(function(data) {
        callback(null, {statusCode:200, body:results});
    }).catch(function(err) {
        callback(err);
    });
};

function covertDate(date) {
        var month = new Array();
        month[0] = "January";
        month[1] = "February";
        month[2] = "March";
        month[3] = "April";
        month[4] = "May";
        month[5] = "June";
        month[6] = "July";
        month[7] = "August";
        month[8] = "September";
        month[9] = "October";
        month[10] = "November";
        month[11] = "December";

        let year = date.slice(0, 4);
        let mon = date.slice(5, 6);
        let day = date.slice(7, 8);
        var d = new Date(year, mon, day);
        return d.getDate() + '-' + month[d.getMonth()] + '-' + d.getFullYear()
    }

function convertTime24to12(time24) {
        var tmpArr = time24.split(':'), time12;
        if (+tmpArr[0] === 12) {
            time12 = tmpArr[0] + ':' + tmpArr[1] + ' pm';
        } else {
            if (+tmpArr[0] === '00') {
                time12 = '12:' + tmpArr[1] + ' am';
            } else {
                if (+tmpArr[0] > 12) {
                    time12 = (+tmpArr[0] - 12) + ':' + tmpArr[1] + ' pm';
                } else {
                    time12 = (+tmpArr[0]) + ':' + tmpArr[1] + ' am';
                }
            }
        }
        return time12;
    }